
function setup() {
  createCanvas(800,800);

  
}

function draw() {
  background("black");  
 
  
}




